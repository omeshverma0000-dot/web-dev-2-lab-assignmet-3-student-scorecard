export default function StudentRow({ student, updateScore }) {
  const pass = student.score >= 40;

  return (
    <tr className="text-center border-t">
      <td className="p-2">{student.name}</td>
      <td>
        <input
          type="number"
          value={student.score}
          onChange={(e) => updateScore(student.id, e.target.value)}
          className="border p-1 rounded w-20 text-center"
        />
      </td>
      <td className={pass ? "text-green-600 font-semibold" : "text-red-600 font-semibold"}>
        {pass ? "Pass" : "Fail"}
      </td>
    </tr>
  );
}
