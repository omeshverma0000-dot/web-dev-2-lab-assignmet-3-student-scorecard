import React, { useState } from "react";
import Header from "./components/Header";
import StudentTable from "./components/StudentTable";
import AddStudentForm from "./components/AddStudentForm";

export default function App() {
  const [students, setStudents] = useState([
    { id: 1, name: "Aman", score: 75 },
    { id: 2, name: "Riya", score: 35 }
  ]);

  const addStudent = (name, score) => {
    setStudents([...students, { id: Date.now(), name, score: Number(score) }]);
  };

  const updateScore = (id, score) => {
    setStudents(students.map(s => s.id === id ? {...s, score: Number(score)} : s));
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <Header />
      <AddStudentForm addStudent={addStudent} />
      <StudentTable students={students} updateScore={updateScore} />
    </div>
  );
}
