import StudentRow from "./StudentRow";

export default function StudentTable({ students, updateScore }) {
  return (
    <table className="w-full bg-white shadow rounded">
      <thead className="bg-gray-200">
        <tr>
          <th className="p-3">Name</th>
          <th className="p-3">Score</th>
          <th className="p-3">Status</th>
        </tr>
      </thead>
      <tbody>
        {students.map(s => (
          <StudentRow key={s.id} student={s} updateScore={updateScore} />
        ))}
      </tbody>
    </table>
  );
}
