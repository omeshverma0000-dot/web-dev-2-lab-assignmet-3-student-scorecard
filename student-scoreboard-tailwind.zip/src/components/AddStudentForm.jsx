import { useState } from "react";

export default function AddStudentForm({ addStudent }) {
  const [name, setName] = useState("");
  const [score, setScore] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (!name || !score) return;
    addStudent(name, score);
    setName("");
    setScore("");
  };

  return (
    <form onSubmit={submit} className="mb-6 flex gap-2 justify-center">
      <input
        className="border p-2 rounded"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        className="border p-2 rounded"
        type="number"
        placeholder="Score"
        value={score}
        onChange={(e) => setScore(e.target.value)}
      />
      <button className="bg-blue-500 text-white px-4 rounded">Add</button>
    </form>
  );
}
